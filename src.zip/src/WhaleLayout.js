import React from 'react';
import WhaleCard from './WhaleCard.js';
import WhaleTest from './WhaleTest.js';

export class WhaleLayout extends React.Component {

    renderWhale(icon) {
        return (<whaleCard />);
    }

    render() {

        return(
            <WhaleCard />
        );
    }

    
}

export default WhaleLayout;