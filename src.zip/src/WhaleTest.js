import React from 'react';

class WhaleTest extends React.Component {
    render() {

        return(
            <div>
                <h1>Fuck React</h1>
            </div>
        );
    }
}

export default WhaleTest